// Kleiner Server: liefert die App aus und leitet den TikTok-Live-Chat per Server-Sent Events an die App weiter.
// Nutzt die inoffizielle Bibliothek "tiktok-live-connector". Sie kann sich ändern oder ausfallen.
const http = require('http');
const fs = require('fs');
const path = require('path');
const lib = require('tiktok-live-connector');

const PORT = process.env.PORT || 3000;
const ACCESS_KEY = process.env.ACCESS_KEY || ''; // optional: schützt /events und /connect
const clients = new Set();
let conn = null;

function broadcast(obj) {
  const msg = 'data: ' + JSON.stringify(obj) + '\n\n';
  for (const res of clients) res.write(msg);
}

async function connectTo(user) {
  if (conn) { try { conn.disconnect(); } catch {} conn = null; }
  const Conn = lib.TikTokLiveConnection || lib.WebcastPushConnection;
  conn = new Conn(user);
  const chatEvent = (lib.WebcastEvent && lib.WebcastEvent.CHAT) || 'chat';
  conn.on(chatEvent, d => {
    const name = (d.user && (d.user.nickname || d.user.uniqueId)) || d.nickname || d.uniqueId || '';
    const text = d.comment || '';
    if (text) broadcast({ type: 'chat', name, text });
  });
  const disc = (lib.ControlEvent && lib.ControlEvent.DISCONNECTED) || 'disconnected';
  conn.on(disc, () => broadcast({ type: 'info', text: 'TikTok-Chat getrennt.', ok: false }));
  await conn.connect();
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const needsKey = url.pathname === '/events' || url.pathname === '/connect';
  if (needsKey && ACCESS_KEY && url.searchParams.get('key') !== ACCESS_KEY) {
    res.writeHead(401); return res.end('Falscher Zugangsschlüssel.');
  }
  if (url.pathname === '/events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    res.write('retry: 3000\n\n');
    clients.add(res);
    const ping = setInterval(() => res.write(': ping\n\n'), 25000);
    req.on('close', () => { clearInterval(ping); clients.delete(res); });
    return;
  }
  if (url.pathname === '/connect') {
    const user = (url.searchParams.get('user') || '').replace(/^@/, '').trim();
    if (!/^[\w.]{2,40}$/.test(user)) { res.writeHead(400); return res.end('Ungültiger Benutzername.'); }
    try {
      await connectTo(user);
      res.writeHead(200); return res.end('Mit @' + user + ' verbunden. Chat läuft.');
    } catch (e) {
      res.writeHead(502);
      return res.end('Keine Verbindung. Läuft ein Live von @' + user + '? (' + (e.message || e) + ')');
    }
  }
  if (url.pathname === '/' || url.pathname === '/index.html') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html')));
  }
  if (url.pathname === '/logo.jpg') {
    res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'public, max-age=86400' });
    return res.end(fs.readFileSync(path.join(__dirname, 'public', 'logo.jpg')));
  }
  res.writeHead(404); res.end('Nicht gefunden');
});

server.listen(PORT, () => console.log('Läuft auf Port ' + PORT));
